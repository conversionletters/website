<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conversion Letters - Sound Human & Connect in the Age of AI</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/kenwheeler/slick@1.8.1/slick/slick.css"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/kenwheeler/slick@1.8.1/slick/slick-theme.css"/>
</head>
<style>

</style>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <img src="public/Blue-Lesson.png" alt="Conversion Letters" class="logo">
            </div>
            <div class="nav-menu" id="nav-menu">
                <a href="#services" class="nav-link">Services</a>
                <a href="#about" class="nav-link">About</a>
                <a href="#process" class="nav-link">Process</a>
                <a href="#results" class="nav-link">Results</a>
                <a href="#faq" class="nav-link">FAQ</a>
                <a href="#audit" class="nav-cta">Book Free Audit</a>
            </div>
            <div class="nav-toggle" id="nav-toggle">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="row hero-slide py-3 mt-5">
                <div class="col-lg-6 pt-3">
                    <h1 class="hero-title">
                        <span class="title-line">Email that scales</span>
                        <span class="title-line gradient-text">with your brand’s <div class="bg-spn">next chapter</div></span>
                    </h1>
                    <p class="hero-subtitle">
                        From your first customer to your millionth, we design campaigns that grow as you do.
                    </p>
                    <div class="hero-cta">
                        <a href="#audit" class="btn-primary">
                            <span>Book Your Free Email Audit</span>
                            <i class="fas fa-arrow-right"></i>
                        </a>
                        <!-- <a href="#services" class="btn-secondary">
                            <span>Explore Services</span>
                            <i class="fas fa-play"></i>
                        </a> -->
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="carousel">
                      <div class="carousel__slide">
                        <div class="carousel__slide__inner">
                          <img class="carousel__image" src="public/slide01.png" alt="Image">
                          <div class="carousel__slide__overlay"></div>
                        </div>
                      </div>

                      <div class="carousel__slide">
                        <div class="carousel__slide__inner">
                          <img class="carousel__image" src="public/slide02.png" alt="Image">
                          <div class="carousel__slide__overlay"></div>
                        </div>
                      </div>

                      <div class="carousel__slide">
                        <div class="carousel__slide__inner">
                          <img class="carousel__image" src="public/slide03.png" alt="Image">
                          <div class="carousel__slide__overlay"></div>
                        </div>
                      </div>

                      <div class="carousel__slide">
                        <div class="carousel__slide__inner">
                          <img class="carousel__image" src="public/slide04.png" alt="Image">
                          <div class="carousel__slide__overlay"></div>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
            <div class="hero-content">
                <div class="hero-stats">
                    <div class="stat-item">
                        <div class="stat-number">42%</div>
                        <div class="stat-label">Increase in open rates</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">$3.5M+</div>
                        <div class="stat-label">Revenue Generated</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">3x</div>
                        <div class="stat-label">more booked calls with our cold emails</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- brand logo Section -->
    <section id="logo" class="py-5 bg-light">
      <div class="container py-3">
        <div class="row justify-content-space-between align-items-center">
          <!-- Left Text -->
          <div class="col-lg-2 col-md-12 mb-4 mb-lg-0 text-lg-start text-center">
            <h5 class="mb-0 text-white">
              We support <br><strong>40+ ESPs</strong>
            </h5>
          </div>

          <!-- Divider -->
          <div class="col-lg-1 d-none d-lg-block">
            <div style="width:1px;height:50px;background:#000;margin:auto;"></div>
          </div>

          <!-- Logos -->
          <div class="col-lg-9 col-md-12 logo-box">
            <div class="row align-items-center g-5 text-center">

              <div class="col p-2">
                <img src="public/brand1.webp" alt="Klaviyo" class="img-fluid">
              </div>

              <div class="col p-2">
                <img src="public/brand2.webp" alt="Mailchimp" class="img-fluid">
              </div>

              <div class="col p-2">
                <img src="public/brand3.webp" alt="Customer.io" class="img-fluid">
              </div>

              <div class="col p-2">
                <img src="public/brand4.webp" alt="Iterable" class="img-fluid">
              </div>

              <div class="col p-2">
                <img src="public/brand5.webp" alt="Braze" class="img-fluid">
              </div>

              <div class="col p-2">
                <img src="public/brand6.webp" alt="Hubspot" class="img-fluid">
              </div>

              <div class="col p-2">
                <img src="public/brand7.webp" alt="Brevo" class="img-fluid">
              </div>

              <div class="col p-2">
                <img src="public/brand8.webp" alt="Dotdigital" class="img-fluid">
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Our Services</div>
                <h2 class="section-title">Everything you need to win with email</h2>
                <p class="section-subtitle">From setup to sales—comprehensive email solutions that deliver results</p>
            </div>
            
            <div class="services-grid">
                <div class="service-card">
                  <div class="service-icon">
                    <i class="fas fa-bullseye"></i>
                  </div>
                  <h3 class="service-title">Cold Email Outreach</h3>
                  <p class="service-description">Outreach that starts real conversations and fills your pipeline.</p>

                  <!-- Features (hidden by default) -->
                  <ul class="service-features" style="display:none;">
                    <li>Research & list building (verified, targeted leads)</li>
                    <li>Copywriting (personalized, human-first messaging)</li>
                    <li>Multi-step campaigns with smart follow-ups</li>
                    <li>Deliverability & inbox placement monitoring</li>
                    <li>Domain setup, warm-up & rotation</li>
                    <li>Performance reporting (opens, replies, meetings booked)</li>
                  </ul>

                  <!-- Buttons -->
                  <button class="read-more-btn">Read More</button>
                  <button class="read-less-btn" style="display:none;">Read Less</button>

                  <div class="service-hover-effect"></div>
                </div>


                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <h3 class="service-title">E-commerce Email Marketing</h3>
                    <p class="service-description">Turn email into your most profitable e-commerce channel.</p>
                    <ul class="service-features" style="display:none;">
                        <li>Email strategy & roadmap</li>
                        <li>ESP setup & migration (Klaviyo, Mailchimp, etc.)</li>
                        <li>Automated flows</li>
                        <li>Promotional campaigns & newsletters</li>
                        <li>Advanced segmentation & personalization</li>
                        <li>Copy, design, & A/B testing</li>
                        <li>Revenue tracking & optimization</li>
                    </ul>
                    <!-- Buttons -->
                    <button class="read-more-btn">Read More</button>
                    <button class="read-less-btn" style="display:none;">Read Less</button>

                    <div class="service-hover-effect"></div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-cogs"></i>
                    </div>
                    <h3 class="service-title">Email Audits & Technical Setup</h3>
                    <p class="service-description">The behind-the-scenes fixes that keep your emails in the inbox.</p>
                    <ul class="service-features" style="display:none;">
                        <li>Full deliverability audit</li>
                        <li>Spam & inbox placement testing</li>
                        <li>Domain authentication (SPF, DKIM, DMARC, BIMI)</li>
                        <li>Domain warm-up & reputation management</li>
                        <li>List cleaning & hygiene</li>
                        <li>Compliance (GDPR, CAN-SPAM, CASL)</li>
                        <li>ESP account setup, integrations & troubleshooting</li>
                    </ul>

                    <!-- Buttons -->
                    <button class="read-more-btn">Read More</button>
                    <button class="read-less-btn" style="display:none;">Read Less</button>

                    <div class="service-hover-effect"></div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3 class="service-title">Campaign Management</h3>
                    <p class="service-description">Ongoing execution and testing to maximize performance month after month.</p>
                    <ul class="service-features" style="display:none;">
                        <li>End-to-end campaign execution</li>
                        <li>Copywriting & creative optimization</li>
                        <li>Data-driven testing (subject lines, CTAs, send times)</li>
                        <li>Conversion rate optimization</li>
                        <li>Performance dashboards & reporting</li>
                        <li>Ongoing growth strategy</li>
                    </ul>

                    <!-- Buttons -->
                    <button class="read-more-btn">Read More</button>
                    <button class="read-less-btn" style="display:none;">Read Less</button>

                    <div class="service-hover-effect"></div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3 class="service-title">List Growth & Lead Capture</h3>
                    <p class="service-description">Build a healthy, growing list of subscribers who actually want to hear from you.</p>
                    <ul class="service-features" style="display:none;">
                        <li>Popups, landing pages, opt-in forms</li>
                        <li>Incentives & lead magnets</li>
                        <li>Integration with CRM & e-commerce platforms</li>
                        <li>Subscriber journey mapping</li>
                    </ul>

                    <!-- Buttons -->
                    <button class="read-more-btn">Read More</button>
                    <button class="read-less-btn" style="display:none;">Read Less</button>

                    <div class="service-hover-effect"></div>
                </div>
            </div>
        </div>
    </section>


    <!-- new first investment -->
    <section id="investment">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">The Last Email Agency You’ll Ever Need</h2>
                <p class="section-subtitle">Strategy, copy, and execution — done right.</p>
            </div>
            
            <div class="img-text-box">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-text">
                            <h2 class="section-title">Where does it come from?</h2>
                            <p class="about-description">
                                We handle every detail so your campaigns hit the mark every time. No wasted effort, no random sends — just consistent, scalable results.
                            </p>
                            <p class="about-description">
                                Each email is crafted to drive real growth, turning your campaigns into a predictable engine that fuels your brand’s success.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <img class="public-image" src="public/slide02.png">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- new second investment -->
    <section id="investment">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">The Email Agency for Ambitious Brands</h2>
                <p class="section-subtitle">Campaigns built to scale, engage, and convert.</p>
            </div>
            
            <div class="img-text-box">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <img class="public-image" src="public/slide03.png">
                    </div>
                    <div class="col-lg-6">
                        <div class="about-text" style="float:right;">
                            <h2 class="section-title">Where does it come from?</h2>
                            <p class="about-description">
                                 We don’t just send emails — we craft campaigns that grow your brand and drive measurable revenue. Every message is part of a precise strategy designed to maximize impact, build loyalty, and compound results over time.
                            </p>
                            <p class="about-description">
                                Our approach turns your inbox into a growth engine that evolves as your business does.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Zero investment -->
    <section id="investment">
        <div class="container">
            <div class="section-header mb-2">
                <div class="section-badge">Zero investment</div>
                <h2 class="section-title">Zero investment, Infinite returns.</h2>
                <p class="section-subtitle">This 30 min call could change everything.</p>
            </div>
            
            <div>
                <!-- Calendly inline widget begin -->
                <div class="calendly-inline-widget" data-url="https://calendly.com/harry73/30min" style="min-width:320px;height:700px;"></div>
                <script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script>
                <!-- Calendly inline widget end -->
            </div>
        </div>
    </section>

    <!-- Swiper Section -->
    <!-- <section id="slider" class="img-slider py-2">
        <div class="container">
            <div class="section-header mb-3">
                <div class="section-badge">Clients</div>
                <h2 class="section-title">Our Clients</h2>
                <p class="section-subtitle">Minds Mojo has been honored to partner up with these clients</p>
            </div>
        </div>
        <div class="slider">
            <div class="slide-track">
                <div class="slide">
                  <img src="public/img-slide1.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide2.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide3.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide4.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide5.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide6.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide7.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide8.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide1.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide2.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide3.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide4.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide5.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide6.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide7.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide8.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide1.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide2.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide3.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide4.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide5.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide6.png" alt="" />
                </div>
                <div class="slide">
                  <img src="public/img-slide7.png" alt="" />
                </div>
            </div>
        </div>
    </section> -->

    <!-- Clients Logos Section -->
    <section id="Grid-clients" class="img-slider py-2">
        <div class="container">
            <div class="section-header mb-3">
                <div class="section-badge">Clients</div>
                <h2 class="section-title">Our Clients</h2>
                <p class="section-subtitle">Minds Mojo has been honored to partner up with these clients</p>
            </div>
        </div>
        <div class="container ">
            <div class="row Grid-clients-row">
                <div class="col-md-2 logo-img-box"><img src="public/img-slide1.png" alt="" /></div>
                <div class="col-md-2 logo-img-box"><img src="public/img-slide2.png" alt="" /></div>
                <div class="col-md-2 logo-img-box"><img src="public/img-slide3.png" alt="" /></div>
                <div class="col-md-2 logo-img-box"><img src="public/img-slide4.png" alt="" /></div>
                <div class="col-md-2 logo-img-box"><img src="public/img-slide5.png" alt="" /></div>
                <div class="col-md-2 logo-img-box"><img src="public/img-slide6.png" alt="" /></div>
                <div class="col-md-2 logo-img-box"><img src="public/img-slide7.png" alt="" /></div>
                <div class="col-md-2 logo-img-box"><img src="public/img-slide8.png" alt="" /></div>
                <div class="col-md-2 logo-img-box"><img src="public/img-slide9.png" alt="" /></div>
                <div class="col-md-2 logo-img-box"><img src="public/img-slide10.png" alt="" /></div>
                <div class="col-md-2 logo-img-box"><img src="public/img-slide11.png" alt="" /></div>
            </div>
        </div>
    </section>


    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <div class="section-badge">About Us</div>
                    <h2 class="section-title">Sound human. Sell better.</h2>
                    <p class="about-description">
                        We're a boutique email agency focused on one simple idea: emails should feel like conversations, not broadcasts. In an era of AI noise, we help brands connect with real people using honest, human-first messaging that converts.
                    </p>
                    <p class="about-description">
                        We cover everything from technical setup to full campaign execution—so you get clean deliverability, meaningful opens, and measurable revenue.
                    </p>
                    <div class="about-features">
                        <div class="feature-item">
                            <i class="fas fa-check-circle"></i>
                            <span>Human-first messaging</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-check-circle"></i>
                            <span>End-to-end execution</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-check-circle"></i>
                            <span>Measurable results</span>
                        </div>
                    </div>
                </div>
                <div class="about-visual">
                    <div class="visual-card">
                        <div class="card-header">
                            <div class="card-dots">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </div>
                        <div class="card-content">
                            <div class="metric-row">
                                <span class="metric-label">Open Rate</span>
                                <span class="metric-value">42%</span>
                            </div>
                            <div class="metric-row">
                                <span class="metric-label">Click Rate</span>
                                <span class="metric-value">8.5%</span>
                            </div>
                            <div class="metric-row">
                                <span class="metric-label">Conversion</span>
                                <span class="metric-value">3.2%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Process Section -->
    <section id="process" class="process">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">How We Work</div>
                <h2 class="section-title">Simple. Transparent. Outcome-focused.</h2>
            </div>
            
            <div class="process-timeline">
                <div class="process-step">
                    <div class="step-number">01</div>
                    <div class="step-content">
                        <h3 class="step-title">Discovery</h3>
                        <p class="step-description">We learn your business, audience, and goals with targeted research.</p>
                    </div>
                    <div class="step-connector"></div>
                </div>
                
                <div class="process-step">
                    <div class="step-number">02</div>
                    <div class="step-content">
                        <h3 class="step-title">Strategy</h3>
                        <p class="step-description">Messaging, flows, and a roadmap that match your growth stage.</p>
                    </div>
                    <div class="step-connector"></div>
                </div>
                
                <div class="process-step">
                    <div class="step-number">03</div>
                    <div class="step-content">
                        <h3 class="step-title">Execution</h3>
                        <p class="step-description">Copy, design, deliverability, and launch—done end-to-end.</p>
                    </div>
                    <div class="step-connector"></div>
                </div>
                
                <div class="process-step">
                    <div class="step-number">04</div>
                    <div class="step-content">
                        <h3 class="step-title">Growth</h3>
                        <p class="step-description">Test, analyze, and scale what works.</p>
                    </div>
                </div>
            </div>
            
            <div class="process-footer">
                <p>No jargon. No black boxes. Clear steps, clear results.</p>
            </div>
        </div>
    </section>


    <!-- Portfolio section -->
    <section id="investment">
      <div class="container">
        <div class="section-header">
          <div class="section-badge">Portfolio</div>
          <h2 class="section-title">Design and Development Work</h2>
          <p class="section-subtitle">This 30 min call could change everything.</p>
        </div>

        <div class="row-pg">
          <!-- COLUMN 1 -->
          <div class="column-pg px-1 mt-3">
            <img class="myImages" src="public/Port1.jpg" style="width:100%; height: 340px;">
            <img class="myImages" src="public/Port2.jpg" style="width:100%; height: 340px;">
            <img class="myImages" src="public/Port3.png" style="width:100%; height: 340px;">
          </div>

          <!-- COLUMN 2 -->
          <div class="column-pg px-1">
            <img class="myImages" src="public/Port4.jpg" style="width:100%; height: 340px;">
            <img class="myImages" src="public/Port5.jpg" style="width:100%; height: 340px;">
            <img class="myImages" src="public/Port6.jpg" style="width:100%; height: 340px;">
          </div>

          <!-- COLUMN 3 -->
          <div class="column-pg px-1 mt-3">
            <img class="myImages" src="public/Port7.jpg" style="width:100%; height: 340px;">
            <img class="myImages" src="public/Port8.png" style="width:100%; height: 340px;">
            <img class="myImages" src="public/Port9.jpg" style="width:100%; height: 340px;">
          </div>

          <!-- COLUMN 4 -->
          <div class="column-pg px-1 mt-2">
            <img class="myImages" src="public/Port10.png" style="width:100%; height: 340px;">
            <img class="myImages" src="public/Port11.png" style="width:100%; height: 340px;">
            <img class="myImages" src="public/Port12.jpg" style="width:100%; height: 340px;">
          </div>
        </div>
      </div>
    </section>

    <!-- ✅ Only one modal here -->
    <div id="myModal" class="modal">
      <span class="close">&times;</span>
      <img class="modal-content" id="img01">
      <div id="caption"></div>
    </div>


    <!-- Results Section -->
    <section id="results" class="results">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">Results That Speak</div>
                <h2 class="section-title">We don't do vanity metrics—only business outcomes</h2>
                <p class="section-subtitle">Typical wins we deliver:</p>
            </div>
            
            <div class="results-grid">
                <div class="result-card">
                    <div class="result-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="result-number">42%</div>
                    <div class="result-label">Increase in open rates</div>
                </div>
                
                <div class="result-card">
                    <div class="result-icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="result-number">$3.5M+</div>
                    <div class="result-label">revenue generated</div>
                </div>
                
                <div class="result-card">
                    <div class="result-icon">
                        <i class="fas fa-handshake"></i>
                    </div>
                    <div class="result-number">3x</div>
                    <div class="result-label">more booked calls with our cold emails</div>
                </div>
            </div>
        </div>
    </section>


    <!-- Testimonials Section -->
    <section id="testimonial-slider" class="testimonial-slider">
      <div class="container">
        <div class="section-header">
          <div class="section-badge">What Clients Say</div>
          <h2 class="section-title">Trusted by Founders and Marketers</h2>
        </div>
        <div class="testimonial-carousel">
          <div class="testimonial-item">
            <p>"Partnering with Conversion Letters elevated our email marketing to new heights. Their strategic approach and compelling campaigns have significantly boosted our customer engagement and sales."</p>
            <div class="author">
              <div class="avatar">GR</div>
              <div class="info">
                <h4>Bolle Drinks</h4>
                <span><b>Gary Read,</b> CEO, Bolle Drinks</span>
              </div>
            </div>
          </div>

          <div class="testimonial-item">
            <p>"Conversion Letters has been instrumental in transforming our email campaigns. Their expertise in crafting personalized, high-converting emails has led to a noticeable increase in our online sales."</p>
            <div class="author">
              <div class="avatar">LS</div>
              <div class="info">
                <h4>Marleys Homeware</h4>
                <span><b>Lamarl Stafford,</b> CEO & Founder, Marleys Homeware</span>
              </div>
            </div>
          </div>

          <div class="testimonial-item">
            <p>"The team at Conversion Letters truly understands our brand voice. Their tailored email strategies have enhanced our customer retention and driven more bookings."</p>
            <div class="author">
              <div class="avatar">DJ</div>
              <div class="info">
                <h4>Escape City</h4>
                <span><b>Dom Jackman,</b>  Co-Founder, Escape the City</span>
              </div>
            </div>
          </div>

          <div class="testimonial-item">
            <p>"Working with Conversion Letters has been a game-changer. Their data-driven email campaigns have significantly improved our customer engagement and conversion rates."</p>
            <div class="author">
              <div class="avatar">DJ</div>
              <div class="info">
                <h4>Olumui</h4>
                <span><b>Olumuyiwa Olumekun,</b> CEO, Nigerian Aviation Handling Company Plc</span>
              </div>
            </div>
          </div>

          <div class="testimonial-item">
            <p>"Conversion Letters has taken our email marketing to the next level. Their innovative strategies and attention to detail have resulted in increased brand awareness and sales."</p>
            <div class="author">
              <div class="avatar">SA</div>
              <div class="info">
                <h4>Stacey Ayeh,</h4>
                <span><b>Olumuyiwa Olumekun,</b> Founder & Head Brewer, Rock Leopard Brewing</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>


    <!-- FAQ Section -->
    <section id="faq" class="faq">
        <div class="container">
            <div class="section-header">
                <div class="section-badge">FAQ</div>
                <h2 class="section-title">Frequently Asked Questions</h2>
            </div>
            
            <div class="faq-list">
                <div class="faq-item">
                    <div class="faq-question">
                        <span>How soon will I see results?</span>
                        <i class="fas fa-plus"></i>
                    </div>
                    <div class="faq-answer">
                        <p>E-commerce flows often start returning revenue quickly. Cold outreach typically needs 2–4 weeks of testing before scaling.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span>Do you handle copy + design?</span>
                        <i class="fas fa-plus"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Yes. Strategy, copywriting, and design are included—campaigns delivered ready to send.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span>Which platforms do you support?</span>
                        <i class="fas fa-plus"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Klaviyo, Mailchimp, ActiveCampaign, HubSpot, instantly.ai, and other major ESPs.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">
                        <span>Do you require long-term contracts?</span>
                        <i class="fas fa-plus"></i>
                    </div>
                    <div class="faq-answer">
                        <p>No lock-ins. We prefer to earn your trust month to month with results.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section id="audit" class="cta">
        <div class="container">
            <div style="align-items: center;" class="row">
                <div class="col-lg-6">
                    <div class="cta-content">
                        <h2 class="cta-title">Let's make your emails sound human and sell better.</h2>
                        <p class="cta-subtitle">Stop blending in. Start connecting.</p>
                        <div class="cta-buttons">
                            <a href="mailto:hello@conversionletters.com" class="btn-primary">
                                <span>Book Your Free Email Audit</span>
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                        <p class="cta-note">We'll audit one live campaign and show quick wins you can implement now.</p>
                    </div>
                </div>
                <div class="col-lg-6">
                     <div class="form_container">
                        <div class="header">
                            <h1 class="title">Get in Touch</h1>
                        </div>

                        <div class="success-message" id="successMessage">
                            ✨ Thank you! Your message has been sent successfully. We'll get back to you soon.
                        </div>

                        <form id="contactForm" novalidate>
                            <div class="form-group double">
                                <div class="floating-label">
                                    <input type="text" id="firstName" name="firstName" placeholder=" " required>
                                    <label for="firstName">First Name</label>
                                    <div class="error-message">Please enter your first name</div>
                                </div>
                                <div class="floating-label">
                                    <input type="text" id="lastName" name="lastName" placeholder=" " required>
                                    <label for="lastName">Last Name</label>
                                    <div class="error-message">Please enter your last name</div>
                                </div>
                            </div>

                            <div class="form-group floating-label">
                                <input type="email" id="email" name="email" placeholder=" " required>
                                <label for="email">Email Address</label>
                                <div class="error-message">Please enter a valid email address</div>
                            </div>

                            <div class="form-group floating-label">
                                <input type="text" id="company" name="company" placeholder=" ">
                                <label for="company">Company (Optional)</label>
                            </div>

                            <div class="form-group floating-label">
                                <textarea id="message" name="message" placeholder=" " required></textarea>
                                <label for="message">Your Message</label>
                                <div class="error-message">Please enter your message</div>
                            </div>

                            <button type="submit" class="submit-btn" id="submitBtn">
                                Send Message
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <img src="public/Blue-Lesson.png" alt="Conversion Letters" class="footer-logo">
                    <p class="footer-tagline">Sound human. Sell better.</p>
                </div>
                <div class="footer-contact">
                    <a href="mailto:hello@conversionletters.com" class="contact-link">
                        <i class="fas fa-envelope"></i>
                        hello@conversionletters.com
                    </a>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="script.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
      var swiper = new Swiper('.swiper-container', {
        loop: true,
        slidesPerView: 7,
        spaceBetween: 0,

        freeMode: {
          enabled: true,
          momentum: false,
        },

        autoplay: {
          delay: 1, 
          disableOnInteraction: false,
        },

        speed: 4000, 
        grabCursor: true,
        allowTouchMove: true
      });
    });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
          const form = document.getElementById("contactForm");
          const submitBtn = document.getElementById("submitBtn");
          const successMessage = document.getElementById("successMessage");

          // Email validation regex
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

          // Form validation
          function validateField(field) {
            const value = field.value.trim();
            const errorMessage = field.parentNode.querySelector(".error-message");
            let isValid = true;

            // Remove previous error styling
            field.classList.remove("error");
            if (errorMessage) {
              errorMessage.style.display = "none";
            }

            if (field.hasAttribute("required") && !value) {
              isValid = false;
            } else if (field.type === "email" && value && !emailRegex.test(value)) {
              isValid = false;
              if (errorMessage) {
                errorMessage.textContent = "Please enter a valid email address";
              }
            }

            if (!isValid) {
              field.classList.add("error");
              if (errorMessage) {
                errorMessage.style.display = "block";
              }
            }

            return isValid;
          }

          // Real-time validation
          form.addEventListener("input", function (e) {
            if (e.target.matches("input, textarea")) {
              setTimeout(() => validateField(e.target), 300);
            }
          });

          // Form submission
          form.addEventListener("submit", function (e) {
            e.preventDefault();

            const requiredFields = form.querySelectorAll(
              "input[required], textarea[required]"
            );
            let isFormValid = true;

            // Validate all required fields
            requiredFields.forEach((field) => {
              if (!validateField(field)) {
                isFormValid = false;
              }
            });

            if (!isFormValid) {
              // Focus on first invalid field
              const firstError = form.querySelector(".error");
              if (firstError) {
                firstError.focus();
                firstError.scrollIntoView({ behavior: "smooth", block: "center" });
              }
              return;
            }

            // Show loading state
            submitBtn.classList.add("loading");
            submitBtn.textContent = "Sending...";

            // Simulate form submission
            setTimeout(() => {
              // Hide loading state
              submitBtn.classList.remove("loading");
              submitBtn.textContent = "Send Message";

              // Show success message
              successMessage.style.display = "block";
              successMessage.scrollIntoView({ behavior: "smooth", block: "center" });

              // Reset form
              form.reset();

              // Hide success message after 5 seconds
              setTimeout(() => {
                successMessage.style.display = "none";
              }, 5000);
            }, 2000);
          });

          // Enhance accessibility
          const inputs = document.querySelectorAll("input, textarea");
          inputs.forEach((input) => {
            input.addEventListener("focus", function () {
              this.setAttribute("aria-expanded", "true");
            });

            input.addEventListener("blur", function () {
              this.setAttribute("aria-expanded", "false");
            });
          });

          // Add subtle hover effects to form groups
          const formGroups = document.querySelectorAll(".form-group");
          formGroups.forEach((group) => {
            group.addEventListener("mouseenter", function () {
              const input = this.querySelector("input, textarea");
              if (input && !input.matches(":focus")) {
                input.style.transform = "translateY(-1px)";
              }
            });

            group.addEventListener("mouseleave", function () {
              const input = this.querySelector("input, textarea");
              if (input && !input.matches(":focus")) {
                input.style.transform = "translateY(0)";
              }
            });
          });
        });
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    
    <script>
       // find elements
      var carousel = $(".carousel");

      var options = {
        adaptiveHeight: true,
        arrows: false,
        dots: false,
        fade: true,
        infinite: true,           // must be true for autoplay looping
        mobileFirst: true,
        rows: 0,
        slidesToScroll: 1,
        slidesToShow: 1,
        speed: 600,               // transition speed in ms
        zIndex: 75,
        autoplay: true,           // enable autoplay
        autoplaySpeed: 3000       // time between slides in ms (3 seconds)
      };

        var addAnimationClass = true;

        carousel.on("beforeChange", function (e, slick, current, next) {
          var current = carousel.find(".slick-slide")[current];
          var next = carousel.find(".slick-slide")[next];
          var src = $(current).find(".carousel__image").attr("src");

          $(next)
            .find(".carousel__slide__overlay")
            .css("background-image", 'url("' + src + '")');

          if (addAnimationClass) {
            carousel.addClass("doAnimation");

            // so that adding the class only happens once
            addAnimationClass = false;
          }
        });

        carousel.not(".slick-initialized").slick(options);
    </script>


    <script>
      // find elements
      var carousel = $(".carousel2");

      var options = {
        adaptiveHeight: true,
        arrows: false,
        dots: true,
        fade: false,              // ⚠️ disable fade if showing multiple slides
        infinite: true,           
        mobileFirst: true,
        rows: 0,
        slidesToShow: 6,          // show 6 at once
        slidesToScroll: 1,        // scroll 1 at a time
        speed: 600,               
        zIndex: 75,
        autoplay: true,           
        autoplaySpeed: 3000       
      };

      var addAnimationClass = true;

      carousel.on("beforeChange", function (e, slick, current, next) {
        var currentSlide = carousel.find(".slick-slide")[current];
        var nextSlide = carousel.find(".slick-slide")[next];
        var src = $(currentSlide).find(".carousel__image2").attr("src");

        $(nextSlide)
          .find(".carousel__slide__overlay")
          .css("background-image", 'url("' + src + '")');

        if (addAnimationClass) {
          carousel.addClass("doAnimation");
          addAnimationClass = false;
        }
      });

      carousel.not(".slick-initialized").slick(options);
    </script>


    <script>
        document.addEventListener("DOMContentLoaded", function() {
          // Select all service cards
          document.querySelectorAll('.service-card').forEach(function(card) {
            const features = card.querySelector('.service-features');
            const readMoreBtn = card.querySelector('.read-more-btn');
            const readLessBtn = card.querySelector('.read-less-btn');

            // Show list on Read More
            readMoreBtn.addEventListener('click', function() {
              features.style.display = 'block';
              readMoreBtn.style.display = 'none';
              readLessBtn.style.display = 'inline-block';
            });

            // Hide list on Read Less
            readLessBtn.addEventListener('click', function() {
              features.style.display = 'none';
              readMoreBtn.style.display = 'inline-block';
              readLessBtn.style.display = 'none';
            });
          });
        });
    </script>


    <script>
        // Get modal
        var modal = document.getElementById("myModal");
        var modalImg = document.getElementById("img01");
        var captionText = document.getElementById("caption");
        var span = document.getElementsByClassName("close")[0];

        // All images
        var images = document.querySelectorAll(".myImages");

        images.forEach(function(img) {
          img.addEventListener("click", function() {
            modal.style.display = "block";
            modalImg.src = this.src;
            captionText.innerHTML = this.alt || "";
          });
        });

        // Close button
        span.onclick = function() {
          modal.style.display = "none";
        };

        // Optional: close on click outside
        modal.onclick = function(e) {
          if (e.target === modal) {
            modal.style.display = "none";
          }
        };
    </script>

    <!-- Include jQuery & Slick -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>

<script>
$(document).ready(function(){
  $('.testimonial-carousel').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    dots: false,
    arrows: false,
    autoplay: true,
    autoplaySpeed: 3000,
    infinite: true,
    speed: 600,
    responsive: [
      {
        breakpoint: 768,
        settings: { slidesToShow: 1 }
      }
    ]
  });
});
</script>


</body>
</html>